# 🌿 YardShare

**Book unique outdoor spaces for parties, photoshoots, gatherings, and more!**

![YardShare](https://img.shields.io/badge/Status-Live-success) ![React](https://img.shields.io/badge/React-18.2-blue) ![Tailwind](https://img.shields.io/badge/Tailwind-3.3-cyan) ![License](https://img.shields.io/badge/License-MIT-green)

---

## ✨ Features

- 🔍 **Search & Filter** - Find outdoor spaces by location, type, and availability
- ⭐ **Browse by Ratings** - Sort by price, distance, and guest ratings
- 💚 **Save Favorites** - Bookmark your favorite yards for quick access
- 🎨 **Beautiful UI** - Euphoric design with smooth animations
- 📱 **Fully Responsive** - Works perfectly on all devices
- 🏡 **Multiple Space Types** - Gardens, rooftops, backyards, meadows, and more

---

## 🚀 Quick Start

### Prerequisites

- Node.js 16+ and npm installed
- Git installed

### Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/yardshare.git
cd yardshare

# Install dependencies
npm install

# Start development server
npm run dev
```

Visit `http://localhost:5173` to see the app running! 🎉

---

## 🛠️ Tech Stack

- **Frontend Framework:** React 18
- **Build Tool:** Vite
- **Styling:** Tailwind CSS
- **Icons:** Lucide React
- **Deployment:** Netlify (recommended)

---

## 📦 Available Scripts

```bash
# Development server with hot reload
npm run dev

# Build for production
npm run build

# Preview production build locally
npm run preview
```

---

## 🏗️ Project Structure

```
yardshare/
├── public/              # Static assets
├── src/
│   ├── App.jsx         # Main application component
│   ├── index.css       # Tailwind imports & global styles
│   └── main.jsx        # React entry point
├── index.html          # HTML template
├── package.json        # Dependencies
├── tailwind.config.js  # Tailwind configuration
├── vite.config.js      # Vite configuration
└── README.md           # You are here!
```

---

## 🎨 Customization

### Colors

The app uses a beautiful emerald & teal gradient theme. To customize colors, edit `tailwind.config.js`:

```js
theme: {
  extend: {
    colors: {
      // Add your custom colors here
    }
  }
}
```

### Adding More Yards

Edit the `yards` array in `src/App.jsx` to add more spaces:

```js
{
  id: 7,
  name: "Your Space Name",
  location: "City, State",
  distance: "X.X mi",
  price: 100,
  rating: 4.8,
  reviews: 50,
  capacity: 30,
  image: "your-image-url",
  type: "garden", // garden, rooftop, backyard, meadow, patio, forest
  amenities: ["Amenity 1", "Amenity 2"]
}
```

---

## 🚀 Deployment

### Deploy to Netlify

1. Push your code to GitHub
2. Visit [Netlify](https://app.netlify.com)
3. Click "Add new site" → "Import an existing project"
4. Select your repository
5. Build settings (auto-detected):
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
6. Click "Deploy site"

Your site will be live in minutes! 🎉

### Deploy to Vercel

```bash
npm install -g vercel
vercel
```

---

## 🌟 Features Roadmap

- [ ] User authentication
- [ ] Real booking system with calendar
- [ ] Payment integration (Stripe)
- [ ] Host dashboard
- [ ] Review & rating system
- [ ] Map view for listings
- [ ] Advanced search filters
- [ ] Messaging between hosts & guests
- [ ] Mobile app (React Native)

---

## 🤝 Contributing

Contributions are welcome! Here's how:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 📝 License

This project is licensed under the MIT License. See [LICENSE](LICENSE) for details.

---

## 💚 Support

If you like YardShare, please:
- ⭐ Star this repository
- 🐛 Report bugs via GitHub Issues
- 💡 Suggest features via GitHub Discussions
- 📣 Share with others who might find it useful!

---

## 🎉 Live Demo

🔗 **[View Live Site](https://your-site.netlify.app)** *(Add your deployment URL here)*

---

## 📧 Contact

Have questions or feedback? Reach out!

- **GitHub:** [@YOUR_USERNAME](https://github.com/YOUR_USERNAME)
- **Email:** your.email@example.com

---

<div align="center">

**Made with 💚 for outdoor lovers everywhere**

[Report Bug](https://github.com/YOUR_USERNAME/yardshare/issues) • [Request Feature](https://github.com/YOUR_USERNAME/yardshare/issues)

</div>
