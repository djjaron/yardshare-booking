import React, { useState } from 'react';
import { Heart, MapPin, Star, Users, Search, Filter, Calendar, DollarSign, Sparkles, Sun, Trees, Home } from 'lucide-react';

const YardShare = () => {
  const [favorites, setFavorites] = useState(new Set());
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const yards = [
    {
      id: 1,
      name: "Secret Garden Oasis",
      location: "Berkeley, CA",
      distance: "2.3 mi",
      price: 75,
      rating: 4.9,
      reviews: 124,
      capacity: 25,
      image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&h=600&fit=crop",
      type: "garden",
      amenities: ["WiFi", "Parking", "BBQ Grill"]
    },
    {
      id: 2,
      name: "Sunset View Rooftop",
      location: "San Francisco, CA",
      distance: "4.1 mi",
      price: 125,
      rating: 5.0,
      reviews: 89,
      capacity: 40,
      image: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&h=600&fit=crop",
      type: "rooftop",
      amenities: ["City Views", "Lounge Area", "String Lights"]
    },
    {
      id: 3,
      name: "Enchanted Forest Clearing",
      location: "Oakland, CA",
      distance: "5.7 mi",
      price: 95,
      rating: 4.8,
      reviews: 67,
      capacity: 30,
      image: "https://images.unsplash.com/photo-1600607687644-c7171b42498b?w=800&h=600&fit=crop",
      type: "forest",
      amenities: ["Fire Pit", "Picnic Tables", "Nature Trails"]
    },
    {
      id: 4,
      name: "Bohemian Backyard Paradise",
      location: "Oakland, CA",
      distance: "3.2 mi",
      price: 60,
      rating: 4.7,
      reviews: 156,
      capacity: 20,
      image: "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=800&h=600&fit=crop",
      type: "backyard",
      amenities: ["Hammocks", "Outdoor Kitchen", "Cozy Seating"]
    },
    {
      id: 5,
      name: "Modern Minimalist Patio",
      location: "San Jose, CA",
      distance: "8.4 mi",
      price: 85,
      rating: 4.9,
      reviews: 92,
      capacity: 35,
      image: "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800&h=600&fit=crop",
      type: "patio",
      amenities: ["Modern Furniture", "Sound System", "Ambient Lighting"]
    },
    {
      id: 6,
      name: "Whimsical Wildflower Meadow",
      location: "Mill Valley, CA",
      distance: "12.1 mi",
      price: 110,
      rating: 5.0,
      reviews: 43,
      capacity: 50,
      image: "https://images.unsplash.com/photo-1600607688969-a5bfcd646154?w=800&h=600&fit=crop",
      type: "meadow",
      amenities: ["Open Space", "Mountain Views", "Wildlife"]
    }
  ];

  const toggleFavorite = (id) => {
    const newFavorites = new Set(favorites);
    if (newFavorites.has(id)) {
      newFavorites.delete(id);
    } else {
      newFavorites.add(id);
    }
    setFavorites(newFavorites);
  };

  const filteredYards = yards.filter(yard => {
    const matchesSearch = yard.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         yard.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filter === 'all' || yard.type === filter;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50 border-b border-emerald-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-br from-emerald-400 to-teal-500 p-2 rounded-xl shadow-lg">
                <Trees className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                  YardShare
                </h1>
                <p className="text-sm text-gray-500">Find your perfect outdoor space</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button className="hidden sm:flex items-center space-x-2 px-4 py-2 rounded-full border-2 border-emerald-200 hover:border-emerald-400 transition-all duration-300 hover:shadow-md">
                <Home className="w-4 h-4 text-emerald-600" />
                <span className="text-sm font-medium text-emerald-700">List your space</span>
              </button>
              <button className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-full hover:shadow-lg transition-all duration-300 transform hover:scale-105">
                <span className="text-sm font-medium">Sign in</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center mb-8">
            <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full mb-4">
              <Sparkles className="w-4 h-4" />
              <span className="text-sm font-medium">Book unique outdoor spaces</span>
            </div>
            <h2 className="text-4xl sm:text-5xl font-bold mb-4">
              Your Next Celebration
              <br />
              <span className="text-emerald-100">Starts in Someone's Yard</span>
            </h2>
            <p className="text-xl text-emerald-50 max-w-2xl mx-auto">
              From garden parties to photoshoots, find the perfect outdoor space for any occasion
            </p>
          </div>

          {/* Search Bar */}
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-2xl shadow-2xl p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="relative">
                  <MapPin className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Where to?"
                    className="w-full pl-11 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-emerald-400 focus:outline-none text-gray-800"
                  />
                </div>
                <div className="relative">
                  <Calendar className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="When?"
                    className="w-full pl-11 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-emerald-400 focus:outline-none text-gray-800"
                  />
                </div>
                <button className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-xl transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2">
                  <Search className="w-5 h-5" />
                  <span>Search</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-wrap gap-3">
          <button
            onClick={() => setFilter('all')}
            className={`px-6 py-2.5 rounded-full font-medium transition-all duration-300 ${
              filter === 'all'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg scale-105'
                : 'bg-white text-gray-700 hover:bg-gray-50 border-2 border-gray-200'
            }`}
          >
            All Spaces
          </button>
          <button
            onClick={() => setFilter('garden')}
            className={`px-6 py-2.5 rounded-full font-medium transition-all duration-300 ${
              filter === 'garden'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg scale-105'
                : 'bg-white text-gray-700 hover:bg-gray-50 border-2 border-gray-200'
            }`}
          >
            🌸 Gardens
          </button>
          <button
            onClick={() => setFilter('rooftop')}
            className={`px-6 py-2.5 rounded-full font-medium transition-all duration-300 ${
              filter === 'rooftop'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg scale-105'
                : 'bg-white text-gray-700 hover:bg-gray-50 border-2 border-gray-200'
            }`}
          >
            🏙️ Rooftops
          </button>
          <button
            onClick={() => setFilter('backyard')}
            className={`px-6 py-2.5 rounded-full font-medium transition-all duration-300 ${
              filter === 'backyard'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg scale-105'
                : 'bg-white text-gray-700 hover:bg-gray-50 border-2 border-gray-200'
            }`}
          >
            🏡 Backyards
          </button>
          <button
            onClick={() => setFilter('meadow')}
            className={`px-6 py-2.5 rounded-full font-medium transition-all duration-300 ${
              filter === 'meadow'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg scale-105'
                : 'bg-white text-gray-700 hover:bg-gray-50 border-2 border-gray-200'
            }`}
          >
            🌾 Meadows
          </button>
        </div>
      </div>

      {/* Listings Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredYards.map((yard) => (
            <div
              key={yard.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className="relative">
                <img
                  src={yard.image}
                  alt={yard.name}
                  className="w-full h-64 object-cover"
                />
                <button
                  onClick={() => toggleFavorite(yard.id)}
                  className={`absolute top-4 right-4 p-2.5 rounded-full backdrop-blur-sm transition-all duration-300 ${
                    favorites.has(yard.id)
                      ? 'bg-red-500 shadow-lg scale-110'
                      : 'bg-white/80 hover:bg-white'
                  }`}
                >
                  <Heart
                    className={`w-5 h-5 ${
                      favorites.has(yard.id) ? 'text-white fill-white' : 'text-gray-600'
                    }`}
                  />
                </button>
                <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full">
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    <span className="text-sm font-bold text-gray-800">{yard.rating}</span>
                    <span className="text-sm text-gray-600">({yard.reviews})</span>
                  </div>
                </div>
              </div>

              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-2">{yard.name}</h3>
                
                <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
                  <div className="flex items-center space-x-1">
                    <MapPin className="w-4 h-4" />
                    <span>{yard.location}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <span className="text-gray-400">•</span>
                    <span>{yard.distance}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-1 text-gray-600">
                    <Users className="w-4 h-4" />
                    <span className="text-sm">Up to {yard.capacity} guests</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <DollarSign className="w-5 h-5 text-emerald-600" />
                    <span className="text-2xl font-bold text-emerald-600">{yard.price}</span>
                    <span className="text-sm text-gray-500">/hour</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 mb-4">
                  {yard.amenities.map((amenity, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-medium"
                    >
                      {amenity}
                    </span>
                  ))}
                </div>

                <button className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105">
                  Book Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Trees className="w-6 h-6" />
                <span className="text-xl font-bold">YardShare</span>
              </div>
              <p className="text-emerald-100 text-sm">
                Connecting people with beautiful outdoor spaces for unforgettable experiences.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Explore</h4>
              <ul className="space-y-2 text-emerald-100 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">Find Spaces</a></li>
                <li><a href="#" className="hover:text-white transition-colors">List Your Space</a></li>
                <li><a href="#" className="hover:text-white transition-colors">How It Works</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Safety</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-emerald-100 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Press</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-emerald-100 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-emerald-500 mt-8 pt-8 text-center text-emerald-100 text-sm">
            <p>© 2025 YardShare. All rights reserved. Made with 💚 for outdoor lovers.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default YardShare;
