# 🚀 YardShare Setup Guide

Your YardShare project is ready! Follow these steps to get it running locally and deployed to GitHub.

---

## 📋 What You Have

All project files are created in the `yardshare/` folder:
- ✅ React + Vite configuration
- ✅ Tailwind CSS setup
- ✅ Complete YardShare application
- ✅ README, LICENSE, .gitignore
- ✅ All dependencies configured

---

## 🏃‍♂️ Quick Start (Local Development)

### Step 1: Navigate to the project
```bash
cd yardshare
```

### Step 2: Install dependencies
```bash
npm install
```

This will install:
- React & React DOM
- Vite (build tool)
- Tailwind CSS
- Lucide React (icons)
- All dev dependencies

### Step 3: Start the development server
```bash
npm run dev
```

🎉 Open your browser to `http://localhost:5173` to see YardShare live!

---

## 📤 Push to GitHub

### Step 1: Initialize Git
```bash
cd yardshare
git init
```

### Step 2: Add all files
```bash
git add .
```

### Step 3: Create your first commit
```bash
git commit -m "Initial commit: YardShare outdoor space booking platform 🌿"
```

### Step 4: Create GitHub repository

**Option A: GitHub Website**
1. Go to https://github.com/new
2. Repository name: `yardshare`
3. Description: "Book unique outdoor spaces for any occasion 🌿"
4. Choose **Public** or **Private**
5. **DO NOT** initialize with README (we already have one!)
6. Click "Create repository"

**Option B: GitHub CLI** (if installed)
```bash
gh repo create yardshare --public --source=. --remote=origin --push
```

### Step 5: Connect to GitHub and push

Replace `YOUR_USERNAME` with your actual GitHub username:

```bash
git remote add origin https://github.com/YOUR_USERNAME/yardshare.git
git branch -M main
git push -u origin main
```

✅ Your code is now on GitHub!

---

## 🌐 Deploy to Netlify

### Method 1: Netlify Website (Recommended for Beginners)

1. **Sign up/Login** to [Netlify](https://app.netlify.com)
2. Click "**Add new site**" → "**Import an existing project**"
3. Choose "**Deploy with GitHub**"
4. Authorize Netlify to access your repositories
5. Select the `yardshare` repository
6. **Build settings** (should auto-detect):
   - Build command: `npm run build`
   - Publish directory: `dist`
7. Click "**Deploy site**"

🎉 Your site will be live in 1-2 minutes!

### Method 2: Netlify CLI

```bash
# Install Netlify CLI globally
npm install -g netlify-cli

# Login to Netlify
netlify login

# Initialize and deploy
cd yardshare
netlify init
netlify deploy --prod
```

---

## 🎨 Customization Tips

### Change the color scheme
Edit `tailwind.config.js` to customize colors:
```js
theme: {
  extend: {
    colors: {
      'brand-primary': '#your-color',
    }
  }
}
```

### Add more yard listings
Edit the `yards` array in `src/App.jsx`

### Modify the hero text
Update the hero section in `src/App.jsx`

---

## 🔧 Available Commands

```bash
npm run dev      # Start development server
npm run build    # Build for production
npm run preview  # Preview production build
```

---

## 📝 Update Your README

Don't forget to update these in `README.md`:
1. Replace `YOUR_USERNAME` with your GitHub username
2. Add your live site URL after deployment
3. Add your email/contact info

---

## 🎯 Next Steps

1. ✅ Install dependencies (`npm install`)
2. ✅ Run locally (`npm run dev`)
3. ✅ Push to GitHub
4. ✅ Deploy to Netlify
5. 🎨 Customize colors & content
6. 🚀 Share your live site!

---

## 💡 Pro Tips

- **Automatic Deployments**: After initial Netlify setup, every push to `main` branch auto-deploys
- **Environment Variables**: Add any API keys in Netlify dashboard under "Site settings" → "Environment variables"
- **Custom Domain**: Connect your own domain in Netlify settings
- **HTTPS**: Automatically enabled on Netlify!

---

## 🆘 Troubleshooting

**Problem:** `npm install` fails
- **Solution:** Make sure you have Node.js 16+ installed (`node --version`)

**Problem:** Port 5173 already in use
- **Solution:** Kill the process or Vite will auto-assign a new port

**Problem:** Build fails on Netlify
- **Solution:** Check build logs in Netlify dashboard. Usually dependency issues.

**Problem:** Images not loading
- **Solution:** Using Unsplash URLs requires internet connection. Images load from CDN.

---

## 📞 Need Help?

- 🐛 Found a bug? [Open an issue](https://github.com/YOUR_USERNAME/yardshare/issues)
- 💬 Questions? Check the main [README.md](README.md)
- 📚 Learn more about [React](https://react.dev), [Vite](https://vitejs.dev), [Tailwind](https://tailwindcss.com)

---

**Happy Coding! 🌿✨**
